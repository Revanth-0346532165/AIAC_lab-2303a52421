import { useEffect, useRef, useState, useCallback } from "react";

export type GazeDirection = "left" | "center" | "right" | "unknown";

interface GazeState {
  direction: GazeDirection;
  confidence: number;
  fps: number;
  faceDetected: boolean;
  rawNoseX: number;
}

const SMOOTHING = 0.15;
const LEFT_THRESHOLD = -0.06;
const RIGHT_THRESHOLD = 0.06;
const HYSTERESIS = 0.02;

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const s = document.createElement("script");
    s.src = src;
    s.crossOrigin = "anonymous";
    s.onload = () => resolve();
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

export function useGazeTracking(videoRef: React.RefObject<HTMLVideoElement | null>) {
  const [state, setState] = useState<GazeState>({
    direction: "center",
    confidence: 0,
    fps: 0,
    faceDetected: false,
    rawNoseX: 0,
  });

  const smoothedX = useRef(0);
  const lastDirection = useRef<GazeDirection>("center");
  const frameCount = useRef(0);
  const lastFpsTime = useRef(Date.now());
  const currentFps = useRef(0);
  const animFrameId = useRef<number>(0);
  const faceMeshRef = useRef<any>(null);

  const detect = useCallback(async () => {
    const video = videoRef.current;
    if (!video || !faceMeshRef.current || video.readyState < 2) {
      animFrameId.current = requestAnimationFrame(detect);
      return;
    }

    try {
      await faceMeshRef.current.send({ image: video });
    } catch {
      // ignore transient errors
    }

    frameCount.current++;
    const now = Date.now();
    if (now - lastFpsTime.current >= 1000) {
      currentFps.current = frameCount.current;
      frameCount.current = 0;
      lastFpsTime.current = now;
    }

    animFrameId.current = requestAnimationFrame(detect);
  }, [videoRef]);

  useEffect(() => {
    let cancelled = false;

    async function init() {
      await loadScript(
        "https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4.1633559619/face_mesh.js"
      );

      if (cancelled) return;

      const win = window as any;
      const FaceMesh = win.FaceMesh;
      if (!FaceMesh) return;

      const faceMesh = new FaceMesh({
        locateFile: (file: string) =>
          `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4.1633559619/${file}`,
      });

      faceMesh.setOptions({
        maxNumFaces: 1,
        refineLandmarks: false,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      faceMesh.onResults((results: any) => {
        if (!results.multiFaceLandmarks || results.multiFaceLandmarks.length === 0) {
          setState((s) => ({ ...s, faceDetected: false, confidence: 0, fps: currentFps.current }));
          return;
        }

        const landmarks = results.multiFaceLandmarks[0];
        const noseTip = landmarks[1];
        const leftCheek = landmarks[234];
        const rightCheek = landmarks[454];
        const faceCenter = (leftCheek.x + rightCheek.x) / 2;
        const faceWidth = Math.abs(rightCheek.x - leftCheek.x);

        const offset = (noseTip.x - faceCenter) / (faceWidth || 1);

        smoothedX.current += (offset - smoothedX.current) * SMOOTHING;
        const sx = smoothedX.current;

        let dir: GazeDirection = lastDirection.current;
        if (dir === "center") {
          if (sx < LEFT_THRESHOLD) dir = "left";
          else if (sx > RIGHT_THRESHOLD) dir = "right";
        } else if (dir === "left") {
          if (sx > LEFT_THRESHOLD + HYSTERESIS) dir = "center";
        } else if (dir === "right") {
          if (sx < RIGHT_THRESHOLD - HYSTERESIS) dir = "center";
        }

        lastDirection.current = dir;

        const conf = Math.min(1, Math.abs(sx) / 0.15);

        setState({
          direction: dir,
          confidence: dir === "center" ? 1 - conf : conf,
          fps: currentFps.current,
          faceDetected: true,
          rawNoseX: sx,
        });
      });

      faceMeshRef.current = faceMesh;
      animFrameId.current = requestAnimationFrame(detect);
    }

    init();

    return () => {
      cancelled = true;
      cancelAnimationFrame(animFrameId.current);
      if (faceMeshRef.current) {
        faceMeshRef.current.close();
      }
    };
  }, [detect]);

  return state;
}
