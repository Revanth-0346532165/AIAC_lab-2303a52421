import GazeDemo from "@/components/GazeDemo";

export default function Index() {
  return <GazeDemo />;
}
