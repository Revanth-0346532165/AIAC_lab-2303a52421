import { useRef, useEffect, useState } from "react";
import { useGazeTracking, type GazeDirection } from "@/hooks/useGazeTracking";

const ZONE_LABELS: Record<GazeDirection, string> = {
  left: "Looking Left",
  center: "Looking Center",
  right: "Looking Right",
  unknown: "No Face Detected",
};

export default function GazeDemo() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const gaze = useGazeTracking(videoRef);

  useEffect(() => {
    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: "user" },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setCameraReady(true);
        }
      } catch {
        setCameraError("Camera access denied. Please allow camera access to use this demo.");
      }
    }
    startCamera();
    return () => {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const dir = gaze.faceDetected ? gaze.direction : "unknown";

  const focusX = dir === "left" ? "16.5%" : dir === "right" ? "83.5%" : "50%";

  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      {/* Background scene with 3 zones */}
      <div className="absolute inset-0 flex">
        {(["left", "center", "right"] as const).map((zone) => (
          <div
            key={zone}
            className={`flex-1 bg-cover bg-center ${
              dir === zone || dir === "unknown" ? "zone-clear" : "zone-blur"
            }`}
            style={{
              backgroundImage: "url('/images/scene.jpg')",
              backgroundPosition:
                zone === "left" ? "left center" : zone === "right" ? "right center" : "center",
            }}
          />
        ))}
      </div>

      {/* Radial spotlight overlay */}
      <div
        className="absolute inset-0 pointer-events-none transition-all duration-700 ease-out"
        style={{
          background:
            dir === "unknown"
              ? "transparent"
              : `radial-gradient(ellipse 40% 80% at ${focusX} 50%, transparent 0%, hsl(var(--background) / 0.5) 100%)`,
        }}
      />

      {/* Top HUD */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2">
        <h1 className="text-xl md:text-2xl font-bold tracking-tight text-foreground drop-shadow-lg">
          Adaptive Gaze-Based Focus System
        </h1>
        <p className="text-sm text-muted-foreground font-mono">
          Move your head left / right to change focus
        </p>
      </div>

      {/* Direction label */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
        <div className="glass rounded-2xl px-8 py-4 glow-primary text-center">
          <p className="text-2xl md:text-4xl font-bold text-primary tracking-wide">
            {ZONE_LABELS[dir]}
          </p>
        </div>
      </div>

      {/* Bottom panel */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-3 w-full max-w-xl px-4">
        {/* Stats */}
        <div className="glass rounded-xl px-5 py-3 flex items-center gap-6 font-mono text-xs text-muted-foreground">
          <span>
            FPS: <span className="text-primary font-semibold">{gaze.fps}</span>
          </span>
          <span>
            Confidence:{" "}
            <span className="text-primary font-semibold">
              {(gaze.confidence * 100).toFixed(0)}%
            </span>
          </span>
          <span>
            Face:{" "}
            <span className={gaze.faceDetected ? "text-primary" : "text-destructive"}>
              {gaze.faceDetected ? "Detected" : "Not Found"}
            </span>
          </span>
          <span>
            Offset:{" "}
            <span className="text-accent font-semibold">{gaze.rawNoseX.toFixed(3)}</span>
          </span>
        </div>

        {/* Instructions & Explanation */}
        <div className="glass rounded-xl px-5 py-3 text-center text-xs text-muted-foreground leading-relaxed max-w-lg">
          This demo simulates solving the{" "}
          <span className="text-accent font-semibold">Vergence-Accommodation Conflict</span> by
          dynamically adjusting focus based on user gaze direction — similar to adaptive varifocal
          rendering in VR/AR headsets.
        </div>
      </div>

      {/* Webcam preview */}
      <div className="absolute bottom-6 right-6 z-20">
        <div className="glass rounded-xl overflow-hidden glow-primary w-40 md:w-52">
          <video
            ref={videoRef}
            className="w-full h-auto mirror"
            style={{ transform: "scaleX(-1)" }}
            playsInline
            muted
          />
          {!cameraReady && !cameraError && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-muted-foreground">
              Loading camera…
            </div>
          )}
        </div>
      </div>

      {/* Camera error overlay */}
      {cameraError && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-background/80">
          <div className="glass rounded-2xl px-8 py-6 max-w-md text-center">
            <p className="text-destructive font-semibold mb-2">Camera Error</p>
            <p className="text-sm text-muted-foreground">{cameraError}</p>
          </div>
        </div>
      )}
    </div>
  );
}
